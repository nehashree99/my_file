const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001; // Ensure this matches the port you're using

app.use(bodyParser.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html')); // Serve your HTML file
});

app.post('/api/saveStudent', (req, res) => {
  const studentData = req.body;
  const filePath = path.join(__dirname, 'student.json');

  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      fs.writeFile(filePath, JSON.stringify([studentData], null, 2), (err) => {
        if (err) {
          console.error('Error creating file:', err);
          return res.status(500).json({ message: 'Error saving student data' });
        }
        return res.status(200).json({ message: 'Student data saved successfully' });
      });
    } else {
      fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
          console.error('Error reading file:', err);
          return res.status(500).json({ message: 'Error reading student data' });
        }

        const students = JSON.parse(data);
        students.push(studentData);

        fs.writeFile(filePath, JSON.stringify(students, null, 2), (err) => {
          if (err) {
            console.error('Error writing to file:', err);
            return res.status(500).json({ message: 'Error saving student data' });
          }
          return res.status(200).json({ message: 'Student data saved successfully' });
        });
      });
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
